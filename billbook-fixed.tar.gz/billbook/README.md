# BillBook.in — Complete Setup & Deployment Guide

## Prerequisites
- Node.js 18+
- Supabase account (free) — supabase.com
- Razorpay account (free) — razorpay.com
- Vercel account (free) — vercel.com

---

## Step 1 — Supabase Setup

1. Go to https://supabase.com → New project → name it `billbook`, region `ap-south-1` (Mumbai)
2. Go to SQL Editor → New query → paste all of `supabase-schema.sql` → Run
3. Go to Authentication → Providers → ensure Email is enabled
4. Go to Project Settings → API → copy:
   - Project URL → NEXT_PUBLIC_SUPABASE_URL
   - anon public key → NEXT_PUBLIC_SUPABASE_ANON_KEY
   - service_role key → SUPABASE_SERVICE_ROLE_KEY

---

## Step 2 — Razorpay Setup

1. Go to https://razorpay.com → create free account
2. Settings → API Keys → Generate Key
3. Copy Key ID → NEXT_PUBLIC_RAZORPAY_KEY_ID
4. Copy Key Secret → RAZORPAY_KEY_SECRET
5. Use test keys (rzp_test_...) for development, live keys for production

---

## Step 3 — Environment Variables (.env.local)

```
NEXT_PUBLIC_SUPABASE_URL=https://xxxx.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJ...
SUPABASE_SERVICE_ROLE_KEY=eyJ...
NEXT_PUBLIC_RAZORPAY_KEY_ID=rzp_test_xxx
RAZORPAY_KEY_SECRET=xxx
NEXT_PUBLIC_APP_URL=http://localhost:3000
```

---

## Step 4 — Local Development

```bash
npm install
npm run dev
# Open http://localhost:3000
```

---

## Step 5 — Deploy to Vercel

1. Push to GitHub
2. Import repo at vercel.com
3. Add all env vars in Vercel dashboard
4. Change NEXT_PUBLIC_APP_URL to your Vercel URL
5. Deploy

---

## How PDF Works

Uses the browser Print → Save as PDF. Zero cost, works on all devices.

---

## Free Tier Limits

| Service    | Free Limit                         |
|------------|------------------------------------|
| Supabase   | 500MB DB, 50K rows                 |
| Vercel     | Unlimited deploys, 100GB bandwidth |
| Razorpay   | 2% per transaction only            |

Run BillBook.in free until you have paying users.
